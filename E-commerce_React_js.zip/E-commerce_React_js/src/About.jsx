import React from 'react'
import HeroSection from './component/HeroSection'
import Review from './component/Review'
import Service from './component/Service'
import Number from './component/Number'

const About = () => {
  return (
    <>
      <HeroSection/>
      <Review/>
      <Number/>
      <Service/>
    </>
  )
}

export default About