import React from 'react'
import Blogs from './component/Blogs'

const Blog = () => {
  return (
    <>
    <Blogs/>
    </>
  )
}

export default Blog