import React from 'react'
import Blogs from './component/Blogs'
import Galary from './component/Galary'
import HeroSection from './component/HeroSection'
import Review from './component/Review'
// import Trending from './component/Trending'
import Service from './component/Service'
import Number from './component/Number'

const Home = () => {
  return (
    <>
    <div className="home">
        <HeroSection/>
        {/* <Trending/> */}
        <Galary/>
        <Review/>
        <Blogs/>
        <Number/>
        <Service/>
    </div>
    </>
  )
}

export default Home