import React from 'react'
import { FiShoppingBag } from 'react-icons/fi';
const Checkout = () => {
  return (
    <>
      <div className="container mx-auto">
        <h1 className='text-center'>CheckOut</h1>
        <h2 class="font-semibold text-xl">1. Delivery Details</h2>
        <div class="mx-auto flex my-2">
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="name" class="leading-7 text-sm text-gray-600 dark:text-gray-300">Name</label>
              <input minlength="2" maxlength="40" type="text" id="name" name="name" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="email" class="leading-7 text-sm text-gray-600 dark:text-gray-300">Email</label>
              <input minlength="5" maxlength="320" type="email" id="email" name="email" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>
        </div>
        <div class="px-2 w-full">
          <div class="mb-4">
            <label for="address" class="leading-7 text-sm text-gray-600 dark:text-gray-300">Address</label>
            <textarea minlength="2" maxlength="400" name="address" id="address" cols="30" rows="2" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"></textarea>
          </div>
        </div>
        <div class="mx-auto flex my-2">
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="phone" class="leading-7 text-sm text-gray-600 dark:text-gray-300">Phone Number</label>
              <input minlength="10" maxlength="10" placeholder="Your 10 Digit Phone Number" type="phone" id="phone" name="phone" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="pincode" class="leading-7 text-sm text-gray-600 dark:text-gray-300">PinCode (Shipping only to India)</label>
              <input minlength="6" maxlength="6" type="text" id="pincode" name="pincode" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>

        </div>
        <div class="mx-auto flex my-2">
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="state" class="leading-7 text-sm text-gray-600 dark:text-gray-300">State</label>
              <input type="text" id="state" name="state" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>
          <div class="px-2 w-1/2">
            <div class="mb-4">
              <label for="city" class="leading-7 text-sm text-gray-600 dark:text-gray-300">District</label>
              <input type="text" id="city" name="city" class="w-full bg-white rounded border border-gray-300 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" value="" />
            </div>
          </div>
        </div>
        <h2 class="font-semibold text-xl">2. Review Cart Items & Pay </h2>
        <div class="sideCart bg-red-100 dark:bg-gray-700 rounded-xl p-6 m-2">
          <ol class="list-none font-semibold">
            <div class="my-4 font-semibold">Your cart is Empty!</div>
          </ol><span class="font-bold">Subtotal: ₹0</span>
        </div>
        <div class="flex row justify-between lg:items-center flex-col lg:flex-row">
          <div class="mx-4">
            <div class="form-check flex items-center">
              <input class="mr-2 p-8 md:h-4 md:w-4" type="checkbox" id="flexCheckDefault" value="false" />
              <label class="form-check-label inline-block text-gray-800 dark:text-gray-300" for="flexCheckDefault">
                <p class="py-4">I want to place a Cash on Delivery (COD) Order. I promise to pay the delivery partner on delivery</p>
              </label>
            </div>
          </div>
          <div class="coupon mx-4 my-4 lg:mx-60 ">
            <h3 class="text-gray-600 font-semibold dark:text-gray-300">Apply Promo code</h3>
            <div class="pin my-2 flex space-x-2 text-sm">
              <input class="px-2 border-2 border-gray-400 rounded-md" placeholder="Enter Code (Only Prepaid)" type="text" value="" />
              <button class="text-white bg-red-500 border-0 py-2 px-6 focus:outline-none hover:bg-red-600 rounded disabled:bg-red-200">Apply</button>
            </div>
          </div>
        </div>
        <div class="mx-4">
        <button class="flex justify-between items-center text-white bg-red-500 border-0 py-2 px-6 focus:outline-none hover:bg-red-600 rounded disabled:bg-red-200"><FiShoppingBag/> Pay 0₹</button>
        </div>
      </div>

    </>
  )
}

export default Checkout