import React from 'react'
import Galary from './component/Galary'

const Shop = () => {
  return (
    <>
    <Galary/>
    </>
  )
}

export default Shop