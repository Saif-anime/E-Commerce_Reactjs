import React from 'react'
import BlogCard from './BlogCard'

const Blogs = () => {
  return (
    <>
 <section class="text-gray-600 body-font">
  <div class="container px-5 py-8 mx-auto">
  <h1 className='title-font sm:text-4xl text-3xl mb-4 font-medium text-red-600 text-center'>Our Blogs</h1>
    <div class="flex flex-wrap -m-4">
        <BlogCard/>
    </div>
  </div>
</section>
    </>
  )
}

export default Blogs