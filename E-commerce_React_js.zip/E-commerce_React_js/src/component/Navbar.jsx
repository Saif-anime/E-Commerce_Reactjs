import React from 'react'
import { NavLink } from 'react-router-dom'
import { FaShoppingCart } from 'react-icons/fa';
const Navbar = () => {
    return (
        <>
            <header className="text-gray-600 body-font">
                <div className="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
                    <NavLink to="/" className="flex title-font font-medium items-center text-red-500 mb-4 md:mb-0">
                        <span className="ml-3 text-xl">Saif Shop</span>
                    </NavLink>
                    <nav className="md:ml-auto flex flex-wrap items-center text-base justify-center">
                        <NavLink to="/" className="mr-5 hover:text-red-600">Home</NavLink>
                        <NavLink to="shop" className="mr-5 hover:text-red-600">Shop</NavLink>
                        <NavLink to='about' className="mr-5 hover:text-red-600">About</NavLink>
                        <NavLink to="blog" className="mr-5 hover:text-red-600">Blog</NavLink>
                        <NavLink to="contact" className="mr-5 hover:text-red-600">Contact</NavLink>
                    </nav>
                    <button className="inline-flex items-center border-0 py-1 px-3 focus:outline-none hover: rounded text-base mt-4 md:mt-0"><NavLink to="carts"><FaShoppingCart/></NavLink></button>
                </div>
            </header>
        </>
    )
}

export default Navbar