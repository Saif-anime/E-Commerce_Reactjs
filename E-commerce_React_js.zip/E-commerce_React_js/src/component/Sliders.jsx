import React, { Component } from "react";
import Card from "./Card";



const Sliders = () => {

  return (
    <>




      {/* <Card/> */}


      <div className="container px-5 py-8 mx-auto overflow-hidden">
        <div className="flex w-fit translate-x-0">
          <Card/>
        </div>
      </div>



    </>
  )
}

export default Sliders