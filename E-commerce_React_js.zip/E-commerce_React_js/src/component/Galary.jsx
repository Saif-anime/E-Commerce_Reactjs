import React from 'react'
import Card from './Card'

const Galary = () => {
    return (
        <>
            <section className="text-gray-600 body-font">
                <div className="container px-5 py-8 mx-auto">
                    <h1 className='title-font sm:text-4xl text-3xl mb-4 font-medium text-red-600 text-center'>Our Products</h1>
                    <div className="flex justify-center flex-wrap -m-4">
                      <Card/>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Galary