import React from 'react'
import Sliders from './Sliders'

const Trending = () => {
  return (
    <>
     <div className="container px-5 py-8 mx-auto">
    <h2 className="title-font sm:text-4xl text-3xl mb-4 font-medium text-red-600 text-center"> Trending </h2>
    <Sliders/>
     </div>
    
    </>
  )
}

export default Trending