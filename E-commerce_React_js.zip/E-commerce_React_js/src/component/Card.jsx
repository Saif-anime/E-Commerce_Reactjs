import React from 'react'
import { Link } from 'react-router-dom';
import Product_details from '../producte.json';

const Card = () => {
    return (
        <>

        {
            Product_details.map((curElem)=>{
                const {product_id, product_name, product_img, product_category, product_price} = curElem;

                return(
                    <Link to={`/singleproduct/${product_id}`}>
                    <div style={{"height":"66vh"}} className="lg:w-72 md:w-1/2 p-4 w-full" key={product_id}>
                    <a className="block relative h-94 rounded overflow-hidden">
                        <img alt="ecommerce" className="object-cover object-center w-full h-full block" src={product_img} />
                    </a>
                    <div className="mt-4">
                        <h3 className="text-gray-500 text-xs tracking-widest title-font mb-1">{product_category}</h3>
                        <h2 className="text-gray-900 title-font text-lg font-medium">{product_name}</h2>
                        <p className="mt-1">{product_price}₹</p>
                    </div>
                </div>
                </Link>
                )
            })
        }
           
        </>
    )
}

export default Card