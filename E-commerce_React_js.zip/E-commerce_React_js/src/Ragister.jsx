import React from 'react'

const Ragister = () => {
  return (
    <>
    <h1>Ragister</h1>
    </>
  )
}

export default Ragister