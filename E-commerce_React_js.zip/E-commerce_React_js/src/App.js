import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './component/Navbar'
import Home from './Home'
import About from './About'
import Blog from './Blog'
import Contact from './Contact'
import Login from './Login'
import Shop from './Shop'
import Ragister from './Ragister'
import Carts from './Carts'
import SingleProduct from './SingleProduct'
import Checkout from './Checkout'
import './style.css'
import Footer from './component/Footer'

const App = () => {
  return (
    <>
    <BrowserRouter>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='About' element={<About/>}/>
      <Route path='Blog' element={<Blog/>}/>
      <Route path='Contact' element={<Contact/>}/>
      <Route path='Login' element={<Login/>}/>
      <Route path='Register' element={<Ragister/>}/>
      <Route path='Shop' element={<Shop/>}/>
      <Route path='carts' element={<Carts/>}/>
      <Route path='checkouts' element={<Checkout/>}/>
      <Route path='singleproduct/:id' element={<SingleProduct/>}/>
      <Route path='checkout' element={<Checkout/>}/>
    </Routes>
    <Footer/>
    </BrowserRouter>
    
    </>
  )
}

export default App
